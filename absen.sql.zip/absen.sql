-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Jan 2020 pada 09.05
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `absen`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi`
--

CREATE TABLE `absensi` (
  `id_absensi` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `bulan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `kelas` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `kelas`) VALUES
(28, 'X-RPL'),
(29, 'XI-RPL'),
(31, 'XII-RPL');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekap`
--

CREATE TABLE `rekap` (
  `id_rekap` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `sakit` int(11) NOT NULL,
  `izin` int(11) NOT NULL,
  `alfa` int(11) NOT NULL,
  `tgl` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL,
  `nisn` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `jenis` varchar(40) NOT NULL,
  `id_kelas` varchar(30) NOT NULL,
  `alamat` text NOT NULL,
  `s` int(11) NOT NULL DEFAULT '0',
  `i` int(11) NOT NULL DEFAULT '0',
  `a` int(11) NOT NULL DEFAULT '0',
  `date_created` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `nisn`, `nama`, `jenis`, `id_kelas`, `alamat`, `s`, `i`, `a`, `date_created`) VALUES
(1, '13-063-001', 'Adam Deva Rizkyanto', 'Laki-laki', '29', 'Klapanunngal', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(3, '13-063-002', 'Adi Putra Simanjuntak', 'Laki-laki', '29', 'Klapanunggal', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(4, '13-063-003', 'Adrian Dafa', 'Laki-laki', '29', 'Cipenjo', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(5, '13-063-004', 'Alvira Fatsya', 'Perempuan', '29', 'Rawa Ilat', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(6, '13-063-005', 'Ananda Chepy', 'Laki-laki', '29', 'Tempat', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(7, '13-063-006', 'Antonius Lana Gerald', 'Laki-laki', '29', 'Tempat', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(8, '13-063-007', 'Arfina Nur Fauziah', 'Perempuan', '29', 'RawaHingkik', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(9, '13-063-008', 'Aulia Muflihin', 'Laki-laki', '29', 'Tempat', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(10, '13-063-009', 'Bayu Saputra', 'Laki-laki', '29', 'Mampir', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(11, '13-063-010', 'Boy Estomihi', 'Laki-laki', '29', 'Tempat', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(12, '13-063-011', 'Chika Ardana', 'Perempuan', '29', 'RawaHingkik', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(13, '13-063-012', 'Dela Amelia', 'Perempuan', '29', 'Wanaherang', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(14, '13-063-013', 'Dheanita Indriani', 'Perempuan', '29', 'Kedep', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(15, '13-063-14', 'Diah Putri Agung', 'Perempuan', '29', 'Klapanunggal', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(16, '13-063-15', 'Dimas Agustian', 'Laki-laki', '29', 'Rawa Ilat', 0, 0, 0, 'Jumat, 10 Januari 2020'),
(17, '13-063-16', 'Elisa Natalia', 'Perempuan', '29', 'Pa', 0, 0, 0, 'Jumat, 10 Januari 2020');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(200) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `data_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `is_active`, `data_created`) VALUES
(13, 'Miska Asya', 'miskafitri@gmail.com', 'default.jpg', '$2y$10$tOq/3eSHdBUbp9EHqEXFHuWQlbwI5spFs4h96kHFS2cpUKuHJucly', 2, 1, 1578532989),
(14, 'admin', 'admin@gmail.com', 'default.jpg', '$2y$10$S7xY80Pj52bBdJ9koFGEke51kecNXNNB.Jz1VbLznyQoddivQA8ZS', 1, 1, 1578541278);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id_role` int(11) NOT NULL,
  `role` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id_role`, `role`) VALUES
(1, 'Admin'),
(2, 'User');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id_absensi`);

--
-- Indeks untuk tabel `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indeks untuk tabel `rekap`
--
ALTER TABLE `rekap`
  ADD PRIMARY KEY (`id_rekap`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id_role`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id_absensi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT untuk tabel `rekap`
--
ALTER TABLE `rekap`
  MODIFY `id_rekap` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
